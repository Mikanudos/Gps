# GPS Tracker

Android app that shares the device's location with a Discord channel through a webhook.
Sharing is started manually in the app and is visible through an ongoing Android notification.

## Build

1. Open this folder in Android Studio (Ladybug or newer).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android device.

Requirements: Android Studio, JDK 17, Android SDK 35.

## Use

1. Create a Discord webhook in the destination channel.
2. Open GPS Tracker and paste the webhook URL into the field.
3. Tap **Save webhook**.
4. Grant location permission (and notifications if Android asks).
5. Tap **Start sharing**. Android displays an ongoing location-sharing notification.
6. Tap **Stop sharing** in the app or the notification to stop updates.

The app sends latitude, longitude, accuracy, timestamp, and a Google Maps link.
It requests updates approximately every 15 seconds and posts no more often than every 30 seconds.

## Webhook security

The webhook is a secret. Do not commit it to source control or share screenshots containing it.
If a webhook was exposed, delete/regenerate it in Discord and save the replacement in the app.
The webhook is stored in the app's private SharedPreferences on the device. It is not embedded in the APK.

## Permissions

- Fine/coarse location: required to obtain location.
- Foreground service (location): keeps an explicitly started sharing session visible.
- Notifications: displays the ongoing sharing notification on Android 13+.
- Internet: sends webhook messages.

This project does not start sharing automatically on boot and does not hide its notification.
