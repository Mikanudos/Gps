package com.kanha.gpstracker;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocationShareService extends Service implements LocationListener {
    public static final String ACTION_START = "com.kanha.gpstracker.START";
    public static final String ACTION_STOP = "com.kanha.gpstracker.STOP";
    private static final String CHANNEL_ID = "gps_sharing";
    private static final int NOTIFICATION_ID = 7001;
    private static final long MIN_SEND_INTERVAL_MS = 30_000L;

    private LocationManager locationManager;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private long lastSentAt = 0L;
    private boolean active = false;

    @Override
    public void onCreate() {
        super.onCreate();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSharing();
            return START_NOT_STICKY;
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        beginLocationUpdates();
        return START_NOT_STICKY;
    }

    private void beginLocationUpdates() {
        if (active) return;
        boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) {
            stopSharing();
            return;
        }
        active = true;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 15_000L, 10f, this, Looper.getMainLooper());
            }
            if (coarse && locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 15_000L, 25f, this, Looper.getMainLooper());
            }
            Location last = null;
            try { last = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER); }
            catch (SecurityException ignored) { }
            if (last != null) onLocationChanged(last);
        } catch (SecurityException ignored) {
            stopSharing();
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        if (!active || location == null) return;
        long now = System.currentTimeMillis();
        if (now - lastSentAt < MIN_SEND_INTERVAL_MS) return;
        lastSentAt = now;
        SharedPreferences prefs = getSharedPreferences("gps_tracker", MODE_PRIVATE);
        String webhook = prefs.getString("webhook", "");
        if (!(webhook.startsWith("https://discord.com/api/webhooks/")
                || webhook.startsWith("https://discordapp.com/api/webhooks/"))) return;

        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(new Date(now));
        String maps = "https://www.google.com/maps?q=" + location.getLatitude() + "," + location.getLongitude();
        String content = "GPS Tracker location update\n"
                + "Latitude: " + location.getLatitude() + "\n"
                + "Longitude: " + location.getLongitude() + "\n"
                + "Accuracy: " + (location.hasAccuracy() ? location.getAccuracy() + " m" : "unknown") + "\n"
                + "Time: " + timestamp + "\n"
                + "Map: " + maps;

        networkExecutor.execute(() -> postWebhook(webhook, content));
    }

    private void postWebhook(String webhook, String content) {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(webhook);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(10_000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            String body = "{\"content\":\"" + jsonEscape(content) + "\"}";
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(bytes);
            }
            int status = connection.getResponseCode();
            android.util.Log.i("GPS-Tracker", "Discord webhook HTTP status: " + status);
        } catch (Exception e) {
            android.util.Log.e("GPS-Tracker", "Webhook send failed", e);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String jsonEscape(String value) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"': out.append("\\\""); break;
                case '\\': out.append("\\\\"); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                default:
                    if (c < 0x20) out.append(String.format(Locale.US, "\\u%04x", (int)c));
                    else out.append(c);
            }
        }
        return out.toString();
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, LocationShareService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(
                this, 1, stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                this, 2, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setContentTitle("GPS sharing is active")
                .setContentText("Your location is being sent to the configured Discord webhook.")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .setOngoing(true)
                .setContentIntent(openPending)
                .addAction(android.R.drawable.ic_media_pause, "Stop sharing", stopPending);
        return builder.build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "GPS location sharing", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Visible status for an active location-sharing session.");
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void stopSharing() {
        active = false;
        try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
        stopForeground(true);
        stopSelf();
    }

    @Override public void onProviderEnabled(String provider) { }
    @Override public void onProviderDisabled(String provider) { }
    @Override public void onStatusChanged(String provider, int status, Bundle extras) { }

    @Override
    public void onDestroy() {
        active = false;
        try { locationManager.removeUpdates(this); } catch (Exception ignored) { }
        networkExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
