package com.kanha.gpstracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int PERMISSION_REQUEST = 41;
    private EditText webhookInput;
    private SharedPreferences prefs;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("gps_tracker", MODE_PRIVATE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 40, 36, 32);

        TextView title = new TextView(this);
        title.setText("GPS Tracker");
        title.setTextSize(26);
        layout.addView(title);

        TextView description = new TextView(this);
        description.setText("Location sharing is manual. When active, an ongoing Android notification is shown.");
        description.setTextSize(15);
        addSpace(layout, 12);
        layout.addView(description);

        webhookInput = new EditText(this);
        webhookInput.setHint("Discord webhook URL");
        webhookInput.setSingleLine(true);
        webhookInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        webhookInput.setText(prefs.getString("webhook", ""));
        addSpace(layout, 18);
        layout.addView(webhookInput, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button save = new Button(this);
        save.setText("Save webhook");
        save.setOnClickListener(v -> saveWebhook());
        layout.addView(save);

        Button start = new Button(this);
        start.setText("Start sharing");
        start.setOnClickListener(v -> {
            if (!isValidWebhook(webhookInput.getText().toString().trim())) {
                Toast.makeText(this, "Enter a valid Discord webhook URL first.", Toast.LENGTH_LONG).show();
                return;
            }
            saveWebhook();
            requestNeededPermissions();
        });
        addSpace(layout, 12);
        layout.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop sharing");
        stop.setOnClickListener(v -> stopSharing());
        layout.addView(stop);

        TextView note = new TextView(this);
        note.setText("The device owner must tap Start sharing. Location is sent to the configured Discord channel.");
        note.setTextSize(13);
        addSpace(layout, 18);
        layout.addView(note);

        setContentView(layout);
    }

    private void addSpace(LinearLayout layout, int dp) {
        TextView spacer = new TextView(this);
        spacer.setHeight(dp);
        layout.addView(spacer);
    }

    private void saveWebhook() {
        String value = webhookInput.getText().toString().trim();
        if (!isValidWebhook(value)) {
            Toast.makeText(this, "Webhook URL must start with https://discord.com/api/webhooks/", Toast.LENGTH_LONG).show();
            return;
        }
        prefs.edit().putString("webhook", value).apply();
        Toast.makeText(this, "Webhook saved on this device.", Toast.LENGTH_SHORT).show();
    }

    private boolean isValidWebhook(String value) {
        return value.startsWith("https://discord.com/api/webhooks/")
                || value.startsWith("https://discordapp.com/api/webhooks/");
    }

    private void requestNeededPermissions() {
        boolean fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        boolean coarse = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!fine && !coarse) {
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, PERMISSION_REQUEST);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, PERMISSION_REQUEST);
            return;
        }
        startSharingService();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != PERMISSION_REQUEST) return;
        boolean locationGranted =
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
        if (!locationGranted) {
            Toast.makeText(this, "Location permission is required.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Allow notifications so the sharing status is visible.", Toast.LENGTH_LONG).show();
            return;
        }
        startSharingService();
    }

    private void startSharingService() {
        Intent intent = new Intent(this, LocationShareService.class);
        intent.setAction(LocationShareService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        Toast.makeText(this, "Location sharing started.", Toast.LENGTH_SHORT).show();
    }

    private void stopSharing() {
        Intent intent = new Intent(this, LocationShareService.class);
        intent.setAction(LocationShareService.ACTION_STOP);
        startService(intent);
        Toast.makeText(this, "Stop requested.", Toast.LENGTH_SHORT).show();
    }
}
